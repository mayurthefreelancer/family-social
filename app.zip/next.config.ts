import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {},
  },
  output: "standalone",
  images: {
    localPatterns: [
      {
        pathname: "/uploads/**",
        search: "**",
      },
    ],
  },
};

export default nextConfig;
