import NextAuth from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      familyId?: string;
      role?: string;
      email?: string;
    };
  }
}
